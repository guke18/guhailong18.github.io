﻿=== Fairy Tail Cursor Set ===

By: Kutty

Download: http://www.rw-designer.com/cursor-set/fairy-tail

Author's decription:

Collection of Fairy Tail cursors made from screenshots or chibi versions

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.